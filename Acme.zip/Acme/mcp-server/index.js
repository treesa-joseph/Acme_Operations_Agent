import express from "express";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import pkg from "pg";
const { Pool } = pkg;

const pool = new Pool({
  host: process.env.DB_HOST || "postgres",
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || process.env.POSTGRES_DB || "acme_db",
  user: process.env.DB_USER || process.env.POSTGRES_USER || "app_user",
  password: process.env.DB_PASSWORD || process.env.POSTGRES_PASSWORD || "acme_password",
});

const app = express();
const port = process.env.PORT || 3000;
const transports = new Map();

function createMcpServer() {
  const server = new Server(
    { name: "acme-mcp-server", version: "1.0.0" },
    { capabilities: { tools: {} } }
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: [
      {
        name: "RetrieveCustomerRecord",
        description: "Get customer profile details given a customer name.",
        inputSchema: {
          type: "object",
          properties: { customer_name: { type: "string" } },
          required: ["customer_name"],
        },
      },
      {
        name: "RetrieveCustomerID",
        description: "Get customer ID for a given customer name.",
        inputSchema: {
          type: "object",
          properties: { customer_name: { type: "string" } },
          required: ["customer_name"],
        },
      },
      {
        name: "RetrieveUserRecord",
        description: "Get a user's name and email given a numeric user ID or a username.",
        inputSchema: {
          type: "object",
          properties: { user_id: { type: "string" } },
          required: ["user_id"],
        },
      },
      {
        name: "RetrieveAssignedUser",
        description: "Get the assigned user ID for a given numeric issue ID.",
        inputSchema: {
          type: "object",
          properties: { issue_id: { type: "string" } },
          required: ["issue_id"],
        },
      },
      {
        name: "RetrieveOpenIssues",
        description: "Get all open issues for a numeric customer ID.",
        inputSchema: {
          type: "object",
          properties: { customer_id: { type: "string" } },
          required: ["customer_id"],
        },
      },
      {
        name: "SummariseIssueHistory",
        description: "Summarise update history for a numeric issue ID.",
        inputSchema: {
          type: "object",
          properties: { issue_id: { type: "string" } },
          required: ["issue_id"],
        },
      },
      {
        name: "CreateNextAction",
        description: "Create a next action. Input: issue_id | action_text | assigned_to (a username)",
        inputSchema: {
          type: "object",
          properties: { data: { type: "string" } },
          required: ["data"],
        },
      },
    ],
  }));

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args = {} } = request.params;
    const clean = (v) => String(v ?? "").trim().replace(/^['"]+|['"]+$/g, "").trim();

    const textResult = (text) => ({ content: [{ type: "text", text }] });

    try {
      if (name === "RetrieveCustomerRecord") {
        const customerName = clean(args.customer_name);
        const res = await pool.query(
          "SELECT * FROM customers WHERE lower(name) LIKE lower($1)",
          [`%${customerName}%`]
        );
        if (!res.rows.length) return textResult("No customer found with that name.");
        return textResult(JSON.stringify(res.rows));
      }

      if (name === "RetrieveCustomerID") {
        const customerName = clean(args.customer_name);
        const res = await pool.query(
          "SELECT id FROM customers WHERE lower(name) LIKE lower($1)",
          [`%${customerName}%`]
        );
        if (!res.rows.length) return textResult("No customer found with that name.");
        return textResult(`Customer ID is ${res.rows[0].id}`);
      }

      if (name === "RetrieveUserRecord") {
        const val = clean(args.user_id);
        const res = /^\d+$/.test(val)
          ? await pool.query("SELECT username, email FROM users WHERE id = $1", [Number(val)])
          : await pool.query("SELECT username, email FROM users WHERE lower(username) = lower($1)", [val]);
        if (!res.rows.length) return textResult("No user found.");
        return textResult(`Assigned user name is ${res.rows[0].username} and email is ${res.rows[0].email}`);
      }

      if (name === "RetrieveAssignedUser") {
        const val = clean(args.issue_id);
        if (!/^\d+$/.test(val)) return textResult("Error: issue ID must be a number.");
        const res = await pool.query("SELECT assigned_to_user_id FROM issues WHERE id = $1", [Number(val)]);
        if (!res.rows.length) return textResult(`No issue found with ID ${val}.`);
        return textResult(`Assigned User ID: ${res.rows[0].assigned_to_user_id}`);
      }

      if (name === "RetrieveOpenIssues") {
        const val = clean(args.customer_id);
        if (!/^\d+$/.test(val)) {
          return textResult("Error: customer ID must be a number. Use RetrieveCustomerID first.");
        }
        const res = await pool.query(
          "SELECT id, title, description, status FROM issues WHERE customer_id = $1 AND status NOT IN ('resolved', 'closed')",
          [Number(val)]
        );
        if (!res.rows.length) return textResult("No open issues found for this customer.");
        const formatted = res.rows.map(
          (r) =>
            `Issue id: ${r.id}, Issue title: "${r.title}", Issue description: "${r.description}", Issue status: "${r.status}"`
        );
        return textResult(`Open Issue Records of Customer ID#${val}: ` + formatted.join("\n "));
      }

      if (name === "SummariseIssueHistory") {
        const val = clean(args.issue_id);
        if (!/^\d+$/.test(val)) return textResult("Error: issue ID must be a number.");
        const res = await pool.query(
          "SELECT update_text, user_id, created_at FROM issue_updates WHERE issue_id = $1 ORDER BY created_at DESC",
          [Number(val)]
        );
        if (!res.rows.length) return textResult("No records found for this issue id.");
        const formatted = res.rows.map(
          (r) => `{Update text: "${r.update_text}", author: "${r.user_id}", created_at: "${r.created_at}"}`
        );
        return textResult("Issue Update History: " + formatted.join(", "));
      }

      if (name === "CreateNextAction") {
        const parts = String(args.data ?? "").split("|").map((p) => p.trim());
        if (parts.length < 3) {
          return textResult("Error: Provide format 'issue_id | action_text | assigned_to'");
        }
        const issueId = clean(parts[0]);
        let assignedTo = clean(parts[parts.length - 1]);
        const actionText = parts.slice(1, -1).join(" | ").trim();

        if (!/^\d+$/.test(issueId)) return textResult("Error: issue_id must be a number.");
        if (!actionText) return textResult("Error: action_text is empty.");

        if (!/^\d+$/.test(assignedTo)) {
          const userRes = await pool.query(
            "SELECT id FROM users WHERE lower(username) = lower($1)",
            [assignedTo]
          );
          if (!userRes.rows.length) return textResult(`Error: no user named '${assignedTo}'.`);
          assignedTo = userRes.rows[0].id;
        }

        await pool.query(
          "INSERT INTO next_actions (issue_id, action_description, assigned_to) VALUES ($1, $2, $3)",
          [Number(issueId), actionText, Number(assignedTo)]
        );
        return textResult("Next action successfully created.");
      }

      return textResult(`Unknown tool: ${name}`);
    } catch (err) {
      console.error(`MCP tool ${name} failed:`, err);
      return textResult("Tool error: the input was not valid for this tool. Check the format and try again.");
    }
  });

  return server;
}

app.get("/sse", async (req, res) => {
  const transport = new SSEServerTransport("/messages", res);
  transports.set(transport.sessionId, transport);
  res.on("close", () => transports.delete(transport.sessionId));

  const server = createMcpServer();
  await server.connect(transport);
  console.log(`MCP Client connected via SSE (session ${transport.sessionId})`);
});

app.post("/messages", async (req, res) => {
  const sessionId = req.query.sessionId;
  const transport = transports.get(sessionId);
  if (!transport) {
    return res.status(404).send("Unknown MCP session");
  }
  await transport.handlePostMessage(req, res);
});

app.listen(port, () => {
  console.log(`Acme MCP HTTP/SSE Server listening on port ${port}`);
});