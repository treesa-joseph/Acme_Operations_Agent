-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(50) NOT NULL, -- e.g., 'support_agent', 'admin', 'sales_agent'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Customers Table
CREATE TABLE IF NOT EXISTS customers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    company VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Issues Table
CREATE TABLE IF NOT EXISTS issues (
    id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(id) ON DELETE CASCADE,
    assigned_to_user_id INT REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'open', -- open, in_progress, resolved, closed
    priority VARCHAR(20) DEFAULT 'medium', -- low, medium, high, urgent
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Issue Updates Table
CREATE TABLE IF NOT EXISTS issue_updates (
    id SERIAL PRIMARY KEY,
    issue_id INT REFERENCES issues(id) ON DELETE CASCADE,
    user_id INT REFERENCES users(id) ON DELETE SET NULL,
    update_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Next Actions Table
CREATE TABLE IF NOT EXISTS next_actions (
    id SERIAL PRIMARY KEY,
    issue_id INT REFERENCES issues(id) ON DELETE CASCADE,
    action_description TEXT NOT NULL,
    assigned_to INT REFERENCES users(id) ON DELETE SET NULL,
    due_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending' -- pending, completed
);

-- === SEED DATA ===

-- Users
INSERT INTO users (username, email, role) VALUES
('alice_sales', 'alice@acme.com', 'sales_user'),
('bob_support', 'bob@acme.com', 'support_user'),
('charlie_manager', 'charlie@acme.com', 'support_user'),
('admin', 'admin@acme.com', 'admin')
ON CONFLICT (username) DO NOTHING;

-- Customers
INSERT INTO customers (name, company, email) VALUES
('Sarah Connor', 'Cyberdyne Systems', 'sarah@cyberdyne.com'),
('John Doe', 'Syntac Corp', 'john.doe@syntac.com'),
('Jane Smith', 'Globex Corporation', 'jane@globex.com')
ON CONFLICT (email) DO NOTHING;

-- Issues (mix of open, in_progress, resolved, and closed—including closed issues for Sarah Connor)
INSERT INTO issues (customer_id, assigned_to_user_id, title, description, status, priority)
SELECT c.id, u.id, v.title, v.description, v.status, v.priority
FROM (
    VALUES
        ('sarah@cyberdyne.com', 'alice_sales', 'API authentication failing after token refresh', 'The OAuth2 token endpoint returns 401 unauthorized sporadically when refreshing tokens.', 'in_progress', 'high'),
        ('john.doe@syntac.com', 'alice_sales', 'Webhook notifications delayed', 'Webhooks for order events are taking up to 30 minutes to deliver.', 'open', 'medium'),
        ('jane@globex.com', 'bob_support', 'Billing portal error 500', 'Customer gets a 500 internal server error when trying to update credit card details.', 'open', 'urgent'),
        ('sarah@cyberdyne.com', 'bob_support', 'Exported CSV reports missing timezone offset', 'Scheduled usage CSV exports show UTC timestamps instead of the customer workspace timezone.', 'open', 'medium'),
        ('sarah@cyberdyne.com', 'bob_support', 'Role permissions not syncing immediately after group update', 'Changes to user group assignments in the identity provider take several minutes to reflect in UI actions.', 'in_progress', 'high'),
        ('sarah@cyberdyne.com', 'charlie_manager', 'Request for custom rate limit tier on batch endpoint', 'Customer wants higher burst limits for night-time batch ingestion jobs.', 'open', 'low'),
        ('sarah@cyberdyne.com', 'bob_support', 'SSO redirect loop on initial login callback', 'Users hitting /oauth2callback were redirected back to login when cookie domain mismatched.', 'closed', 'high'),
        ('sarah@cyberdyne.com', 'alice_sales', 'Invoice PDF download timing out for large accounts', 'Generating multi-page annual invoices exceeded the 10s gateway timeout.', 'closed', 'medium'),
        ('john.doe@syntac.com', 'bob_support', 'Duplicate customer records imported from legacy CSV', 'Batch import created duplicate entries when company names had trailing whitespace.', 'closed', 'low'),
        ('jane@globex.com', 'charlie_manager', 'Annual contract renewal seat count adjustment', 'Updated licensed seat count from 50 to 85 after mid-year expansion.', 'closed', 'medium')
) AS v(customer_email, assignee_username, title, description, status, priority)
JOIN customers c ON c.email = v.customer_email
LEFT JOIN users u ON u.username = v.assignee_username;

-- Issue Updates
INSERT INTO issue_updates (issue_id, user_id, update_text)
SELECT i.id, u.id, v.update_text
FROM (
    VALUES
        ('API authentication failing after token refresh', 'alice_sales', 'Investigated Keycloak logs. Found expired client secret configuration.'),
        ('API authentication failing after token refresh', 'alice_sales', 'Rotated secret in Keycloak and updated app environment.'),
        ('Billing portal error 500', 'bob_support', 'Checked PostgreSQL connection pool. It was saturated.'),
        ('Exported CSV reports missing timezone offset', 'bob_support', 'Reproduced issue with a test export and confirmed formatter drops tzinfo.'),
        ('Role permissions not syncing immediately after group update', 'bob_support', 'Verified token cache TTL and session refresh behavior.'),
        ('SSO redirect loop on initial login callback', 'bob_support', 'Fixed callback cookie configuration and verified login flow end-to-end.'),
        ('Invoice PDF download timing out for large accounts', 'alice_sales', 'Moved large PDF rendering to background worker and confirmed customer download works.'),
        ('Duplicate customer records imported from legacy CSV', 'bob_support', 'Normalized whitespace on import and merged duplicate records.'),
        ('Annual contract renewal seat count adjustment', 'charlie_manager', 'Applied 85-seat license update and confirmed billing summary with customer.')
) AS v(issue_title, author_username, update_text)
JOIN issues i ON i.title = v.issue_title
LEFT JOIN users u ON u.username = v.author_username;

-- Next Actions
INSERT INTO next_actions (issue_id, action_description, assigned_to, due_date, status)
SELECT i.id, v.action_description, i.assigned_to_user_id, CURRENT_TIMESTAMP + v.due_interval, v.status
FROM (
    VALUES
        ('API authentication failing after token refresh', 'Verify token refresh flow in staging environment', INTERVAL '1 day', 'pending'),
        ('Webhook notifications delayed', 'Check Redis queue worker health and consumer lag', INTERVAL '2 days', 'pending'),
        ('Billing portal error 500', 'Deploy database connection pool optimization patch', INTERVAL '4 hours', 'pending'),
        ('Exported CSV reports missing timezone offset', 'Update CSV serializer to format timestamps using customer timezone', INTERVAL '2 days', 'pending'),
        ('Role permissions not syncing immediately after group update', 'Confirm force-relogin or shorter token TTL with security team', INTERVAL '1 day', 'pending'),
        ('Request for custom rate limit tier on batch endpoint', 'Review infrastructure capacity and approve rate limit quota', INTERVAL '5 days', 'pending'),
        ('SSO redirect loop on initial login callback', 'Confirm zero 302 loops in auth logs for 24 hours', INTERVAL '-2 days', 'completed'),
        ('Invoice PDF download timing out for large accounts', 'Send confirmation email with sample invoice to customer', INTERVAL '-1 day', 'completed'),
        ('Duplicate customer records imported from legacy CSV', 'Add regression test for whitespace trimming in CSV parser', INTERVAL '-3 days', 'completed'),
        ('Annual contract renewal seat count adjustment', 'Archive signed renewal addendum in account notes', INTERVAL '-1 day', 'completed')
) AS v(issue_title, action_description, due_interval, status)
JOIN issues i ON i.title = v.issue_title;

-- CREATE DATABASE for presisting keycloak
CREATE DATABASE keycloak;