import os
import re
import time
import json
import logging
from pathlib import Path
from typing import Any

import redis
import requests
from fastapi import FastAPI, Depends, HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from jose.exceptions import ExpiredSignatureError
from langchain.agents import initialize_agent, AgentType
from langchain.tools import StructuredTool
from langchain_community.chat_models import ChatOllama
from mcp import ClientSession
from mcp.client.sse import sse_client
from pydantic import BaseModel, Field, create_model

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("acme-app")

app = FastAPI(title="Acme Agentic Assistant API")
security = HTTPBearer()

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://mcp-server:3000/sse")
# The "iss" claim is whatever hostname the BROWSER used to log in (Keycloak's KC_HOSTNAME),
# e.g. http://localhost:8080/realms/master. It is NOT the internal docker hostname.
# Comma-separate several values to accept more than one issuer.
KEYCLOAK_ISSUER_URL = os.getenv("KEYCLOAK_ISSUER_URL", "http://localhost:8080/realms/master")
ALLOWED_ISSUERS = tuple(u.strip().rstrip("/") for u in KEYCLOAK_ISSUER_URL.split(",") if u.strip())
KEYCLOAK_INTERNAL_URL = os.getenv("KEYCLOAK_INTERNAL_URL", "http://keycloak:8080/realms/master").rstrip("/")
SLM_MODEL = os.getenv("SLM_NAME", "phi4")
SLM_BASE_URL = os.getenv("SLM_BASE_URL", "http://localhost:11434")
SKILLS_DIR = Path(os.getenv("SKILLS_DIR", "/app/skills"))

SESSION_TTL_SECONDS = 60 * 60 * 24  # 24 hours
MAX_HISTORY_TURNS = 6
APP_ROLES = ("admin", "support_user", "sales_user")
WRITE_ROLES = {"support_user", "admin"}

BASE_PREFIX = (
    "You are an efficient enterprise operations assistant. "
    "Always use your tools to find customer IDs and open issues step by step. "
    "CRITICAL: As soon as you receive the observation containing the issue records, "
    "you must immediately provide the final response to the user and stop."
)

redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)
_jwks_cache: dict = {"keys": None, "expires_at": 0.0}


# ---------------------------------------------------------------------------
# Skills (per-role prompt files in SKILLS_DIR)
# ---------------------------------------------------------------------------
def _read_skill(name: str) -> str | None:
    path = SKILLS_DIR / f"{name}.md"
    if not path.is_file():
        logger.warning(f"Skill file not found: {path}")
        return None
    # Escape curly braces so LangChain prompt templating does not treat them as variables
    return path.read_text(encoding="utf-8").replace("{", "{{").replace("}", "}}")


def load_skills_for_role(role: str) -> tuple[str, list[str]]:
    """Return (combined skills text, list of files that were loaded)."""
    parts, loaded = [], []
    for name in ("common", role):
        text = _read_skill(name)
        if text:
            parts.append(text)
            loaded.append(f"{name}.md")
    return "\n\n".join(parts), loaded


# ---------------------------------------------------------------------------
# Auth: Cryptographic Keycloak JWKS verification + RBAC role extraction
# ---------------------------------------------------------------------------
def get_keycloak_jwks(force_refresh: bool = False) -> dict:
    """Fetch and cache Keycloak's public signing keys (JWKS)."""
    now = time.time()
    if not force_refresh and _jwks_cache["keys"] and now < _jwks_cache["expires_at"]:
        return _jwks_cache["keys"]

    certs_url = f"{KEYCLOAK_INTERNAL_URL}/protocol/openid-connect/certs"
    resp = requests.get(certs_url, timeout=5)
    resp.raise_for_status()
    jwks = resp.json()
    _jwks_cache["keys"] = jwks
    _jwks_cache["expires_at"] = now + 300  # cache for 5 minutes
    return jwks


def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    token = credentials.credentials

    try:
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
    except JWTError as e:
        logger.error(f"Auth error (malformed JWT header): {e}")
        raise HTTPException(status_code=401, detail="Invalid token header")

    try:
        jwks = get_keycloak_jwks()
        if kid and not any(k.get("kid") == kid for k in jwks.get("keys", [])):
            jwks = get_keycloak_jwks(force_refresh=True)
    except Exception as e:
        logger.error(f"Auth error (failed to fetch Keycloak JWKS): {e}")
        raise HTTPException(status_code=503, detail="Identity provider keys unavailable")

    try:
        # Signature and expiry are verified here. The issuer is checked separately below so
        # that a mismatch can be logged with both values (the usual cause of 401s here).
        claims = jwt.decode(
            token,
            jwks,
            algorithms=["RS256"],
            options={"verify_aud": False, "verify_iss": False},  # access tokens set aud="account"
        )
    except ExpiredSignatureError:
        logger.warning("JWT rejected: token has expired")
        raise HTTPException(
            status_code=401,
            detail="Token expired - please log out and log in again",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except JWTError as e:
        logger.warning(f"JWT signature/claims verification failed: {e}")
        raise HTTPException(
            status_code=401,
            detail="Token signature invalid",
            headers={"WWW-Authenticate": "Bearer"},
        )

    issuer = str(claims.get("iss", "")).rstrip("/")
    if issuer not in ALLOWED_ISSUERS:
        logger.warning(
            f"JWT rejected: issuer {issuer!r} is not in the allowed list {list(ALLOWED_ISSUERS)}. "
            "Set KEYCLOAK_ISSUER_URL to the issuer above (the URL the browser uses for Keycloak)."
        )
        raise HTTPException(
            status_code=401,
            detail="Token issuer not accepted",
            headers={"WWW-Authenticate": "Bearer"},
        )

    username = claims.get("preferred_username")
    if not username:
        raise HTTPException(status_code=401, detail="Token has no preferred_username")

    token_roles = (claims.get("realm_access") or {}).get("roles") or []
    matched_roles = [r for r in APP_ROLES if r in token_roles]

    if not matched_roles:
        logger.warning(
            f"User '{username}' authenticated via Keycloak but has no valid app role in token: {token_roles}"
        )
        raise HTTPException(
            status_code=403, detail=f"User '{username}' has no valid application role assigned"
        )

    # APP_ROLES is ordered highest-to-lowest privilege: admin > support_user > sales_user
    role = matched_roles[0]
    return {"username": username, "role": role, "roles": matched_roles}


# ---------------------------------------------------------------------------
# MCP Client -> LangChain Tool Adapter
# ---------------------------------------------------------------------------
def get_tool_schema(tool_def) -> dict:
    """Newer `mcp` releases expose `input_schema` (snake_case); older ones use `inputSchema`.
    Accept both so the app does not break when the SDK version changes."""
    schema = getattr(tool_def, "input_schema", None) or getattr(tool_def, "inputSchema", None)
    return schema or {}


def normalize_tool_args(param_names: list[str], args: tuple, kwargs: dict) -> dict:
    """Build the MCP `arguments` dict from whatever LangChain hands the tool.

    The ReAct agent often sends a bare string as `action_input`, which LangChain delivers as a
    POSITIONAL argument; a JSON object arrives as keyword arguments, sometimes with a slightly
    wrong key name. Numbers are converted to strings because the MCP tools declare string inputs."""
    arguments = dict(zip(param_names, args))
    arguments.update(kwargs)
    if len(param_names) == 1 and param_names[0] not in arguments and len(arguments) == 1:
        arguments = {param_names[0]: next(iter(arguments.values()))}
    return {k: ("" if v is None else str(v)) for k, v in arguments.items()}


def make_mcp_caller(session, tool_name: str, param_names: list[str], tool_call_logs: list[dict]):
    async def _call_mcp(*args, **kwargs) -> str:
        arguments = normalize_tool_args(param_names, args, kwargs)
        t0 = time.perf_counter()
        try:
            logger.info(f"MCP tool call -> {tool_name}({arguments})")
            result = await session.call_tool(tool_name, arguments=arguments)
            texts = [block.text for block in result.content if getattr(block, "text", None)]
            output = "\n".join(texts) if texts else "No output returned from MCP tool."
            tool_call_logs.append(
                {
                    "tool": tool_name,
                    "args": arguments,
                    "duration_ms": round((time.perf_counter() - t0) * 1000, 2),
                    "status": "ok",
                }
            )
            return output
        except Exception as e:
            duration_ms = round((time.perf_counter() - t0) * 1000, 2)
            logger.error(f"MCP tool {tool_name} failed after {duration_ms}ms: {e}")
            tool_call_logs.append(
                {
                    "tool": tool_name,
                    "args": arguments,
                    "duration_ms": duration_ms,
                    "status": "error",
                    "error": str(e),
                }
            )
            return "Tool error: failed to execute MCP tool. Check input format and try again."

    return _call_mcp


async def load_mcp_tools(
    session: ClientSession, role: str, tool_call_logs: list[dict]
) -> list[StructuredTool]:
    """Discover tools dynamically from the MCP server and wrap them for LangChain."""
    mcp_tools_resp = await session.list_tools()
    lc_tools: list[StructuredTool] = []

    for tool_def in mcp_tools_resp.tools:
        # Enforce RBAC: exclude write tools for read-only roles
        if tool_def.name == "CreateNextAction" and role not in WRITE_ROLES:
            continue

        properties = get_tool_schema(tool_def).get("properties", {})
        field_definitions = {
            param_name: (Any, Field(description=param_meta.get("description", "")))
            for param_name, param_meta in properties.items()
        }
        args_schema = create_model(f"{tool_def.name}Input", **field_definitions)

        lc_tools.append(
            StructuredTool.from_function(
                coroutine=make_mcp_caller(session, tool_def.name, list(properties), tool_call_logs),
                name=tool_def.name,
                description=tool_def.description or tool_def.name,
                args_schema=args_schema,
            )
        )

    return lc_tools


# ---------------------------------------------------------------------------
# Redis Session Memory Helpers
# ---------------------------------------------------------------------------
def load_session_history(username: str, session_id: str) -> str:
    """Fetch recent conversation turns from Redis and format them for prompt context."""
    key = f"session:{username}:{session_id}"
    try:
        raw_items = redis_client.lrange(key, -MAX_HISTORY_TURNS, -1)
    except redis.RedisError as e:
        logger.warning(f"Could not read chat history from Redis: {e}")
        return ""

    if not raw_items:
        return ""

    lines = []
    for item in raw_items:
        try:
            turn = json.loads(item)
            lines.append(f"User: {turn.get('query', '')}\nAssistant: {turn.get('response', '')}")
        except json.JSONDecodeError:
            continue

    return "\n".join(lines)


def save_session_turn(username: str, session_id: str, query: str, response: str) -> None:
    """Persist the completed turn to Redis (best-effort)."""
    key = f"session:{username}:{session_id}"
    try:
        redis_client.rpush(key, json.dumps({"query": query, "response": response}))
        redis_client.expire(key, SESSION_TTL_SECONDS)
    except redis.RedisError as e:
        logger.warning(f"Could not store chat history in Redis: {e}")


# ---------------------------------------------------------------------------
# Response evaluation
# ---------------------------------------------------------------------------
MAX_ATTEMPTS = 3

PLANNING_PATTERNS = re.compile(
    r"\b(i need to|i'll|i will|let me|i'm going to|i am going to|i should|first,? i|"
    r"to do this|to create this|before i can)\b",
    re.IGNORECASE,
)
WRITE_INTENT = re.compile(
    r"\b(create|add|assign|schedule|set up)\b.*\b(next action|action)\b", re.IGNORECASE
)
CLAIMS_DONE = re.compile(r"\b(has been created|have created|created|added|assigned)\b", re.IGNORECASE)


def evaluate_response(query: str, output: str, steps: list, role: str) -> tuple[bool, str]:
    """Return (is_acceptable, reason). `steps` is a list of (AgentAction, observation)."""
    text = (output or "").strip()

    if any(a.tool == "CreateNextAction" and "successfully created" in str(obs) for a, obs in steps):
        return True, "action created"
    if not text:
        return False, "the reply was empty"
    if "iteration limit" in text.lower() or "time limit" in text.lower():
        return False, "the agent ran out of steps"
    if text.endswith("?"):
        return True, "clarifying question"
    if PLANNING_PATTERNS.search(text):
        return False, "it described a plan instead of calling a tool or giving a final answer"

    if WRITE_INTENT.search(query) and role in WRITE_ROLES:
        if any(a.tool == "CreateNextAction" and str(obs).startswith("Error") for a, obs in steps):
            return True, "tool reported an error"
        if CLAIMS_DONE.search(text):
            return False, "it claimed the action was created but CreateNextAction never succeeded"
        return False, "it did not call CreateNextAction"

    return True, "ok"


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------
def flatten_exceptions(exc: BaseException) -> list[BaseException]:
    """The MCP client runs on anyio task groups, which wrap any error raised inside them in an
    ExceptionGroup ("unhandled errors in a TaskGroup"). Return the real underlying exceptions."""
    if isinstance(exc, BaseExceptionGroup):
        leaves: list[BaseException] = []
        for sub_exc in exc.exceptions:
            leaves.extend(flatten_exceptions(sub_exc))
        return leaves
    return [exc]


class QueryRequest(BaseModel):
    query: str
    session_id: str = "default_session"


@app.post("/api/agent/run")
async def run_agent(req: QueryRequest, user: dict = Depends(verify_token)):
    request_start = time.perf_counter()
    skills_text, skills_loaded = load_skills_for_role(user["role"])
    prior_conversation = load_session_history(user["username"], req.session_id)
    llm = ChatOllama(model=SLM_MODEL, base_url=SLM_BASE_URL, temperature=0)
    tool_call_logs: list[dict] = []
    response, ok, reason, attempts = "", False, "", 0
    agent_error: Exception | None = None

    try:
        async with sse_client(MCP_SERVER_URL) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as mcp_session:
                await mcp_session.initialize()
                active_tools = await load_mcp_tools(mcp_session, user["role"], tool_call_logs)

                logger.info(
                    f"User {user['username']} ({user['role']}) | skills: {skills_loaded} "
                    f"| MCP tools: {[t.name for t in active_tools]} | query: {req.query}"
                )

                agent = initialize_agent(
                    active_tools,
                    llm,
                    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
                    verbose=True,
                    handle_parsing_errors=True,
                    max_iterations=5,
                    return_intermediate_steps=True,
                    agent_kwargs={
                        "prefix": (
                            f"{BASE_PREFIX}\n\nFollow these skills and guidelines:\n\n{skills_text}\n\n"
                            "You have access to the following tools:"
                        )
                    },
                )

                base_query = (
                    f"Conversation history:\n{prior_conversation}\n\nCurrent user request: {req.query}"
                    if prior_conversation
                    else req.query
                )
                agent_input = base_query

                for attempt in range(1, MAX_ATTEMPTS + 1):
                    attempts = attempt
                    try:
                        result = await agent.ainvoke({"input": agent_input})
                    except Exception as e:
                        # Record it and leave the MCP block cleanly; it is raised after the block closes
                        logger.error(f"Agent execution error ({type(e).__name__}): {e}", exc_info=True)
                        agent_error = e
                        break

                    response = result.get("output", "")
                    steps = result.get("intermediate_steps", [])
                    ok, reason = evaluate_response(req.query, response, steps, user["role"])
                    logger.info(
                        f"Attempt {attempt}/{MAX_ATTEMPTS}: accepted={ok} ({reason}) "
                        f"| tools used: {[a.tool for a, _ in steps]}"
                    )
                    if ok:
                        break

                    agent_input = (
                        f"{base_query}\n\nNOTE: your previous reply was rejected because {reason}. "
                        "Do not describe your plan. Call the right tool now using the JSON action format, "
                        "then give the Final Answer."
                    )

    except HTTPException:
        raise
    except Exception as e:
        leaves = flatten_exceptions(e)
        for leaf in leaves:
            logger.error(
                f"MCP connection/execution failure ({MCP_SERVER_URL}): {type(leaf).__name__}: {leaf}",
                exc_info=leaf,
            )
        http_exc = next((x for x in leaves if isinstance(x, HTTPException)), None)
        if http_exc is not None:
            raise http_exc
        first = leaves[0]
        raise HTTPException(
            status_code=502,
            detail=f"Failed to communicate with MCP server ({type(first).__name__}: {str(first)[:200]})",
        )

    if agent_error is not None:
        raise HTTPException(
            status_code=500,
            detail=f"The agent could not complete this request ({type(agent_error).__name__}: {str(agent_error)[:200]}).",
        )

    if not ok:
        response = "I couldn't complete that request reliably. Please try rephrasing it, or try again."

    save_session_turn(user["username"], req.session_id, req.query, response)
    total_latency_ms = round((time.perf_counter() - request_start) * 1000, 2)

    return {
        "status": "success" if ok else "incomplete",
        "response": response,
        "role": user["role"],
        "skills_loaded": skills_loaded,
        "attempts": attempts,
        "evaluation": reason,
        "latency_ms": total_latency_ms,
        "tool_calls": tool_call_logs,
    }


@app.get("/api/agent/history/{session_id}")
def get_history(session_id: str, user: dict = Depends(verify_token)):
    key = f"session:{user['username']}:{session_id}"
    try:
        items = redis_client.lrange(key, 0, -1)
    except redis.RedisError as e:
        logger.error(f"Redis error reading history: {e}")
        raise HTTPException(status_code=503, detail="History store unavailable")
    return {
        "session_id": session_id,
        "count": len(items),
        "history": [json.loads(i) for i in items],
    }


@app.get("/api/health")
def health_check():
    try:
        redis_ok = bool(redis_client.ping())
    except redis.RedisError:
        redis_ok = False
    return {"status": "healthy" if redis_ok else "degraded", "redis": redis_ok}