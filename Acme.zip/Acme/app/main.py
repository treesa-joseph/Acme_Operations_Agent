import os
import re
import time
import json
import logging
from pathlib import Path
from typing import Any

import redis
import requests
from fastapi import FastAPI, Depends, HTTPException, Request, Response, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from jose.exceptions import ExpiredSignatureError
from langchain.agents import initialize_agent, AgentType
from langchain.tools import StructuredTool
from langchain_community.chat_models import ChatOllama
from mcp import ClientSession
from mcp.client.sse import sse_client
from pydantic import BaseModel, Field, create_model

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("acme-app")

app = FastAPI(title="Acme Agentic Assistant API")
security = HTTPBearer()

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://mcp-server:3000/sse")
# The "iss" claim is whatever hostname the BROWSER used to log in (Keycloak's KC_HOSTNAME),
# e.g. http://localhost:8080/realms/master. It is NOT the internal docker hostname.
# Comma-separate several values to accept more than one issuer.
KEYCLOAK_ISSUER_URL = os.getenv("KEYCLOAK_ISSUER_URL", "http://localhost:8080/realms/master")
ALLOWED_ISSUERS = tuple(u.strip().rstrip("/") for u in KEYCLOAK_ISSUER_URL.split(",") if u.strip())
KEYCLOAK_INTERNAL_URL = os.getenv("KEYCLOAK_INTERNAL_URL", "http://keycloak:8080/realms/master").rstrip("/")
SLM_MODEL = os.getenv("SLM_NAME", "phi4")
SLM_BASE_URL = os.getenv("SLM_BASE_URL", "http://localhost:11434")
SKILLS_DIR = Path(os.getenv("SKILLS_DIR", "/app/skills"))

SESSION_TTL_SECONDS = 60 * 60 * 24  # 24 hours
MAX_HISTORY_TURNS = 6
APP_ROLES = ("admin", "support_user", "sales_user")
WRITE_ROLES = {"support_user", "admin"}

BASE_PREFIX = (
    "You are an efficient enterprise operations assistant. "
    "Always use your tools to find customer IDs and open issues step by step. "
    "Provide only a clear, concise final answer to the user without exposing internal reasoning or thought steps."
)

redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)
_jwks_cache: dict = {"keys": None, "expires_at": 0.0}


def _elapsed_ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 2)


# ---------------------------------------------------------------------------
# Skills (per-role prompt files in SKILLS_DIR)
# ---------------------------------------------------------------------------
def _read_skill(name: str) -> str | None:
    path = SKILLS_DIR / f"{name}.md"
    if not path.is_file():
        logger.warning(f"Skill file not found: {path}")
        return None
    # Escape curly braces so LangChain prompt templating does not treat them as variables
    return path.read_text(encoding="utf-8").replace("{", "{{").replace("}", "}}")


def load_skills_for_role(role: str) -> tuple[str, list[str]]:
    """Return (combined skills text, list of files that were loaded)."""
    parts, loaded = [], []
    for name in ("common", role):
        text = _read_skill(name)
        if text:
            parts.append(text)
            loaded.append(f"{name}.md")
    return "\n\n".join(parts), loaded


# ---------------------------------------------------------------------------
# Auth: Cryptographic Keycloak JWKS verification + RBAC role extraction
# ---------------------------------------------------------------------------
def get_keycloak_jwks(force_refresh: bool = False) -> dict:
    """Fetch and cache Keycloak's public signing keys (JWKS)."""
    now = time.time()
    if not force_refresh and _jwks_cache["keys"] and now < _jwks_cache["expires_at"]:
        return _jwks_cache["keys"]

    certs_url = f"{KEYCLOAK_INTERNAL_URL}/protocol/openid-connect/certs"
    resp = requests.get(certs_url, timeout=5)
    resp.raise_for_status()
    jwks = resp.json()
    _jwks_cache["keys"] = jwks
    _jwks_cache["expires_at"] = now + 300  # cache for 5 minutes
    return jwks


def verify_token(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> dict:
    auth_start = time.perf_counter()
    token = credentials.credentials

    try:
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
    except JWTError as e:
        logger.error(f"Auth error (malformed JWT header): {e}")
        raise HTTPException(status_code=401, detail="Invalid token header")

    try:
        jwks = get_keycloak_jwks()
        if kid and not any(k.get("kid") == kid for k in jwks.get("keys", [])):
            jwks = get_keycloak_jwks(force_refresh=True)
    except Exception as e:
        logger.error(f"Auth error (failed to fetch Keycloak JWKS): {e}")
        raise HTTPException(status_code=503, detail="Identity provider keys unavailable")

    try:
        claims = jwt.decode(
            token,
            jwks,
            algorithms=["RS256"],
            options={"verify_aud": False, "verify_iss": False},
        )
    except ExpiredSignatureError:
        logger.warning("JWT rejected: token has expired")
        raise HTTPException(
            status_code=401,
            detail="Token expired - please log out and log in again",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except JWTError as e:
        logger.warning(f"JWT signature/claims verification failed: {e}")
        raise HTTPException(
            status_code=401,
            detail="Token signature invalid",
            headers={"WWW-Authenticate": "Bearer"},
        )

    issuer = str(claims.get("iss", "")).rstrip("/")
    if issuer not in ALLOWED_ISSUERS:
        logger.warning(
            f"JWT rejected: issuer {issuer!r} is not in the allowed list {list(ALLOWED_ISSUERS)}. "
            "Set KEYCLOAK_ISSUER_URL to the issuer above (the URL the browser uses for Keycloak)."
        )
        raise HTTPException(
            status_code=401,
            detail="Token issuer not accepted",
            headers={"WWW-Authenticate": "Bearer"},
        )

    username = claims.get("preferred_username")
    if not username:
        raise HTTPException(status_code=401, detail="Token has no preferred_username")

    token_roles = (claims.get("realm_access") or {}).get("roles") or []
    matched_roles = [r for r in APP_ROLES if r in token_roles]

    if not matched_roles:
        logger.warning(
            f"User '{username}' authenticated via Keycloak but has no valid app role in token: {token_roles}"
        )
        raise HTTPException(
            status_code=403, detail=f"User '{username}' has no valid application role assigned"
        )

    role = matched_roles[0]
    request.state.auth_latency_ms = _elapsed_ms(auth_start)
    return {"username": username, "role": role, "roles": matched_roles}


# ---------------------------------------------------------------------------
# MCP Client -> LangChain Tool Adapter
# ---------------------------------------------------------------------------
def get_tool_schema(tool_def) -> dict:
    schema = getattr(tool_def, "input_schema", None) or getattr(tool_def, "inputSchema", None)
    return schema or {}


def normalize_tool_args(param_names: list[str], args: tuple, kwargs: dict) -> dict:
    arguments = dict(zip(param_names, args))
    arguments.update(kwargs)
    if len(param_names) == 1 and param_names[0] not in arguments and len(arguments) == 1:
        arguments = {param_names[0]: next(iter(arguments.values()))}
    return {k: ("" if v is None else str(v)) for k, v in arguments.items()}


def make_mcp_caller(
    session,
    tool_name: str,
    param_names: list[str],
    tool_call_logs: list[dict],
    db_fetched_outputs: list[str],
):
    async def _call_mcp(*args, **kwargs) -> str:
        arguments = normalize_tool_args(param_names, args, kwargs)
        t0 = time.perf_counter()
        try:
            logger.info(f"MCP tool call -> {tool_name}({arguments})")
            result = await session.call_tool(tool_name, arguments=arguments)
            duration_ms = _elapsed_ms(t0)
            texts = [block.text for block in result.content if getattr(block, "text", None)]
            output = "\n".join(texts) if texts else "No output returned from MCP tool."
            db_fetched_outputs.append(output)
            logger.info(f"MCP tool call <- {tool_name} completed in {duration_ms}ms")
            tool_call_logs.append(
                {
                    "tool": tool_name,
                    "args": arguments,
                    "duration_ms": duration_ms,
                    "status": "ok",
                }
            )
            return output
        except Exception as e:
            duration_ms = _elapsed_ms(t0)
            logger.error(f"MCP tool {tool_name} failed after {duration_ms}ms: {e}")
            tool_call_logs.append(
                {
                    "tool": tool_name,
                    "args": arguments,
                    "duration_ms": duration_ms,
                    "status": "error",
                    "error": str(e),
                }
            )
            return "Tool error: failed to execute MCP tool. Check input format and try again."

    return _call_mcp


async def load_mcp_tools(
    session: ClientSession,
    role: str,
    tool_call_logs: list[dict],
    db_fetched_outputs: list[str],
) -> list[StructuredTool]:
    """Discover tools dynamically from the MCP server and wrap them for LangChain."""
    mcp_tools_resp = await session.list_tools()
    lc_tools: list[StructuredTool] = []

    for tool_def in mcp_tools_resp.tools:
        if tool_def.name == "CreateNextAction" and role not in WRITE_ROLES:
            continue

        properties = get_tool_schema(tool_def).get("properties", {})
        field_definitions = {
            param_name: (Any, Field(description=param_meta.get("description", "")))
            for param_name, param_meta in properties.items()
        }
        args_schema = create_model(f"{tool_def.name}Input", **field_definitions)

        lc_tools.append(
            StructuredTool.from_function(
                coroutine=make_mcp_caller(
                    session, tool_def.name, list(properties), tool_call_logs, db_fetched_outputs
                ),
                name=tool_def.name,
                description=tool_def.description or tool_def.name,
                args_schema=args_schema,
            )
        )

    return lc_tools


# ---------------------------------------------------------------------------
# Redis Session Memory Helpers
# ---------------------------------------------------------------------------
def load_session_history(username: str, session_id: str) -> str:
    """Fetch recent conversation turns from Redis and format them for prompt context."""
    key = f"session:{username}:{session_id}"
    try:
        raw_items = redis_client.lrange(key, -MAX_HISTORY_TURNS, -1)
    except redis.RedisError as e:
        logger.warning(f"Could not read chat history from Redis: {e}")
        return ""

    if not raw_items:
        return ""

    lines = []
    for item in raw_items:
        try:
            turn = json.loads(item)
            lines.append(f"User: {turn.get('query', '')}\nAssistant: {turn.get('response', '')}")
        except json.JSONDecodeError:
            continue

    return "\n".join(lines)


def save_session_turn(username: str, session_id: str, query: str, response: str) -> None:
    """Persist the completed turn to Redis (best-effort)."""
    key = f"session:{username}:{session_id}"
    try:
        redis_client.rpush(key, json.dumps({"query": query, "response": response}))
        redis_client.expire(key, SESSION_TTL_SECONDS)
    except redis.RedisError as e:
        logger.warning(f"Could not store chat history in Redis: {e}")


# ---------------------------------------------------------------------------
# Response & DB Grounding Evaluation
# ---------------------------------------------------------------------------
MAX_ATTEMPTS = 3

PLANNING_PATTERNS = re.compile(
    r"\b(i need to|i'll|i will|let me|i'm going to|i am going to|i should|first,? i|"
    r"to do this|to create this|before i can)\b",
    re.IGNORECASE,
)
WRITE_INTENT = re.compile(
    r"\b(create|add|assign|schedule|set up)\b.*\b(next action|action)\b", re.IGNORECASE
)
CLAIMS_DONE = re.compile(r"\b(has been created|have created|created|added|assigned)\b", re.IGNORECASE)
DATA_QUERY_PATTERNS = re.compile(
    r"\b(issue|issues|customer|client|assigned|assignee|history|status|open)\b",
    re.IGNORECASE,
)
STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "have", "has", "had",
    "are", "was", "were", "been", "being", "into", "about", "your", "user",
    "issue", "issues", "customer", "client", "open", "status", "history",
    "action", "next", "summary", "details", "found", "none", "there", "are",
}


def evaluate_response(query: str, output: str, steps: list, role: str) -> tuple[bool, str]:
    """Return (is_acceptable, reason). `steps` is a list of (AgentAction, observation)."""
    text = (output or "").strip()

    if any(a.tool == "CreateNextAction" and "successfully created" in str(obs) for a, obs in steps):
        return True, "action created"
    if not text:
        return False, "the reply was empty"
    if "iteration limit" in text.lower() or "time limit" in text.lower():
        return False, "the agent ran out of steps"
    if text.endswith("?"):
        return True, "clarifying question"
    if PLANNING_PATTERNS.search(text):
        return False, "it described a plan instead of calling a tool or giving a final answer"

    if WRITE_INTENT.search(query) and role in WRITE_ROLES:
        if any(a.tool == "CreateNextAction" and str(obs).startswith("Error") for a, obs in steps):
            return True, "tool reported an error"
        if CLAIMS_DONE.search(text):
            return False, "it claimed the action was created but CreateNextAction never succeeded"
        return False, "it did not call CreateNextAction"

    return True, "ok"


def evaluate_db_grounding(
    query: str,
    response: str,
    tool_call_logs: list[dict],
    db_fetched_outputs: list[str],
) -> dict[str, Any]:
    """Verify whether the Phi-4 response is grounded in DB/MCP tool results."""
    successful_calls = [c for c in tool_call_logs if c.get("status") == "ok"]
    combined_db_text = "\n".join(db_fetched_outputs).strip()
    resp_text = (response or "").strip()

    if not combined_db_text:
        no_tool_data = bool(DATA_QUERY_PATTERNS.search(query)) and not resp_text.endswith("?")
        return {
            "grounded": not no_tool_data,
            "score": 0.0 if no_tool_data else 1.0,
            "tool_calls_used": len(successful_calls),
            "ungrounded_numbers": [],
            "matched_tokens": [],
            "reason": (
                "No database/MCP records were fetched for a data-related query"
                if no_tool_data
                else "No DB lookup required or clarifying question asked"
            ),
        }

    db_lower = combined_db_text.lower()
    db_numbers = set(re.findall(r"\b\d+\b", combined_db_text))
    resp_numbers = set(re.findall(r"\b\d+\b", resp_text))
    ungrounded_numbers = sorted(num for num in resp_numbers if num not in db_numbers)

    db_tokens = {
        tok.lower()
        for tok in re.findall(r"\b[a-zA-Z0-9_-]{3,}\b", combined_db_text)
        if tok.lower() not in STOPWORDS
    }
    resp_tokens = [
        tok.lower()
        for tok in re.findall(r"\b[a-zA-Z0-9_-]{3,}\b", resp_text)
        if tok.lower() not in STOPWORDS
    ]
    unique_resp_tokens = list(dict.fromkeys(resp_tokens))
    matched_tokens = [tok for tok in unique_resp_tokens if tok in db_lower or tok in db_tokens]

    overlap_ratio = (
        round(len(matched_tokens) / len(unique_resp_tokens), 2)
        if unique_resp_tokens
        else 1.0
    )
    grounded = (len(ungrounded_numbers) == 0) and (
        overlap_ratio >= 0.25 or len(matched_tokens) >= 2
    )

    reasons: list[str] = []
    if ungrounded_numbers:
        reasons.append(f"numbers/IDs not present in DB results: {ungrounded_numbers}")
    if overlap_ratio < 0.25 and len(matched_tokens) < 2:
        reasons.append(f"low overlap with DB results ({overlap_ratio})")

    return {
        "grounded": grounded,
        "score": overlap_ratio,
        "tool_calls_used": len(successful_calls),
        "ungrounded_numbers": ungrounded_numbers,
        "matched_tokens": matched_tokens[:15],
        "reason": "; ".join(reasons) if reasons else "Response aligns with fetched DB/MCP records",
    }


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------
def flatten_exceptions(exc: BaseException) -> list[BaseException]:
    """The MCP client runs on anyio task groups, which wrap any error raised inside them in an
    ExceptionGroup ("unhandled errors in a TaskGroup"). Return the real underlying exceptions."""
    if isinstance(exc, BaseExceptionGroup):
        leaves: list[BaseException] = []
        for sub_exc in exc.exceptions:
            leaves.extend(flatten_exceptions(sub_exc))
        return leaves
    return [exc]


class QueryRequest(BaseModel):
    query: str
    session_id: str = "default_session"


@app.post("/api/agent/run")
async def run_agent(
    request: Request,
    response_obj: Response,
    req: QueryRequest,
    user: dict = Depends(verify_token),
):
    request_start = time.perf_counter()
    auth_latency_ms = getattr(request.state, "auth_latency_ms", 0.0)

    skills_start = time.perf_counter()
    skills_text, skills_loaded = load_skills_for_role(user["role"])
    skills_latency_ms = _elapsed_ms(skills_start)

    history_start = time.perf_counter()
    prior_conversation = load_session_history(user["username"], req.session_id)
    history_load_latency_ms = _elapsed_ms(history_start)

    llm = ChatOllama(model=SLM_MODEL, base_url=SLM_BASE_URL, temperature=0)
    tool_call_logs: list[dict] = []
    db_fetched_outputs: list[str] = []
    attempt_latencies_ms: list[dict] = []
    response, ok, reason, attempts = "", False, "", 0
    agent_error: Exception | None = None
    mcp_setup_latency_ms = 0.0
    agent_total_latency_ms = 0.0

    try:
        mcp_setup_start = time.perf_counter()
        async with sse_client(MCP_SERVER_URL) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as mcp_session:
                await mcp_session.initialize()
                active_tools = await load_mcp_tools(
                    mcp_session, user["role"], tool_call_logs, db_fetched_outputs
                )
                mcp_setup_latency_ms = _elapsed_ms(mcp_setup_start)

                logger.info(
                    f"User {user['username']} ({user['role']}) | skills: {skills_loaded} "
                    f"| MCP tools: {[t.name for t in active_tools]} | query: {req.query}"
                )

                agent = initialize_agent(
                    active_tools,
                    llm,
                    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
                    verbose=False,
                    handle_parsing_errors=True,
                    max_iterations=5,
                    return_intermediate_steps=True,
                    agent_kwargs={
                        "prefix": (
                            f"{BASE_PREFIX}\n\nFollow these skills and guidelines:\n\n{skills_text}\n\n"
                            "You have access to the following tools:"
                        )
                    },
                )

                base_query = (
                    f"Conversation history:\n{prior_conversation}\n\nCurrent user request: {req.query}"
                    if prior_conversation
                    else req.query
                )
                agent_input = base_query

                agent_loop_start = time.perf_counter()
                for attempt in range(1, MAX_ATTEMPTS + 1):
                    attempts = attempt
                    attempt_start = time.perf_counter()
                    try:
                        result = await agent.ainvoke({"input": agent_input})
                    except Exception as e:
                        attempt_ms = _elapsed_ms(attempt_start)
                        attempt_latencies_ms.append(
                            {
                                "attempt": attempt,
                                "duration_ms": attempt_ms,
                                "accepted": False,
                                "reason": f"error: {type(e).__name__}",
                            }
                        )
                        logger.error(f"Agent execution error ({type(e).__name__}): {e}", exc_info=True)
                        agent_error = e
                        break

                    attempt_ms = _elapsed_ms(attempt_start)
                    response = (result.get("output", "") or "").strip()
                    steps = result.get("intermediate_steps", [])
                    ok, reason = evaluate_response(req.query, response, steps, user["role"])
                    attempt_latencies_ms.append(
                        {
                            "attempt": attempt,
                            "duration_ms": attempt_ms,
                            "accepted": ok,
                            "reason": reason,
                        }
                    )
                    logger.info(
                        f"Attempt {attempt}/{MAX_ATTEMPTS}: accepted={ok} ({reason}) "
                        f"in {attempt_ms}ms | tools used: {[a.tool for a, _ in steps]}"
                    )
                    if ok:
                        break

                    agent_input = (
                        f"{base_query}\n\nNOTE: your previous reply was rejected because {reason}. "
                        "Do not describe your plan or show reasoning steps. Call the right tool now "
                        "using the JSON action format, then give only the Final Answer."
                    )
                agent_total_latency_ms = _elapsed_ms(agent_loop_start)

    except HTTPException:
        raise
    except Exception as e:
        leaves = flatten_exceptions(e)
        for leaf in leaves:
            logger.error(
                f"MCP connection/execution failure ({MCP_SERVER_URL}): {type(leaf).__name__}: {leaf}",
                exc_info=leaf,
            )
        http_exc = next((x for x in leaves if isinstance(x, HTTPException)), None)
        if http_exc is not None:
            raise http_exc
        first = leaves[0]
        raise HTTPException(
            status_code=502,
            detail=f"Failed to communicate with MCP server ({type(first).__name__}: {str(first)[:200]})",
        )

    if agent_error is not None:
        raise HTTPException(
            status_code=500,
            detail=f"The agent could not complete this request ({type(agent_error).__name__}: {str(agent_error)[:200]}).",
        )

    if not ok:
        response = "I couldn't complete that request reliably. Please try rephrasing it, or try again."

    grounding_eval_start = time.perf_counter()
    grounding_eval = evaluate_db_grounding(
        query=req.query,
        response=response,
        tool_call_logs=tool_call_logs,
        db_fetched_outputs=db_fetched_outputs,
    )
    grounding_eval_latency_ms = _elapsed_ms(grounding_eval_start)
    logger.info(
        f"DB grounding evaluation: grounded={grounding_eval['grounded']} "
        f"score={grounding_eval['score']} ({grounding_eval['reason']})"
    )

    save_start = time.perf_counter()
    save_session_turn(user["username"], req.session_id, req.query, response)
    history_save_latency_ms = _elapsed_ms(save_start)

    tool_calls_total_ms = round(sum(t.get("duration_ms", 0.0) for t in tool_call_logs), 2)
    total_latency_ms = _elapsed_ms(request_start)
    response_obj.headers["X-Latency-Ms"] = str(total_latency_ms)

    latency_breakdown = {
        "total_ms": total_latency_ms,
        "auth_ms": auth_latency_ms,
        "skills_load_ms": skills_latency_ms,
        "history_load_ms": history_load_latency_ms,
        "mcp_setup_ms": mcp_setup_latency_ms,
        "agent_total_ms": agent_total_latency_ms,
        "tool_calls_total_ms": tool_calls_total_ms,
        "grounding_eval_ms": grounding_eval_latency_ms,
        "history_save_ms": history_save_latency_ms,
        "attempts": attempt_latencies_ms,
    }

    logger.info(
        f"Request completed for {user['username']} ({user['role']}) in {total_latency_ms}ms "
        f"| auth={auth_latency_ms}ms mcp_setup={mcp_setup_latency_ms}ms "
        f"agent={agent_total_latency_ms}ms tools={tool_calls_total_ms}ms"
    )

    return {
        "status": "success" if ok else "incomplete",
        "response": response,
        "role": user["role"],
        "skills_loaded": skills_loaded,
        "attempts": attempts,
        "evaluation": reason,
        "grounding_evaluation": grounding_eval,
        "latency_ms": total_latency_ms,
        "latency": latency_breakdown,
        "tool_calls": tool_call_logs,
    }


@app.get("/api/agent/history/{session_id}")
def get_history(session_id: str, user: dict = Depends(verify_token)):
    start = time.perf_counter()
    key = f"session:{user['username']}:{session_id}"
    try:
        items = redis_client.lrange(key, 0, -1)
    except redis.RedisError as e:
        logger.error(f"Redis error reading history: {e}")
        raise HTTPException(status_code=503, detail="History store unavailable")
    return {
        "session_id": session_id,
        "count": len(items),
        "latency_ms": _elapsed_ms(start),
        "history": [json.loads(i) for i in items],
    }


@app.get("/api/health")
def health_check():
    start = time.perf_counter()
    try:
        redis_ok = bool(redis_client.ping())
    except redis.RedisError:
        redis_ok = False
    return {
        "status": "healthy" if redis_ok else "degraded",
        "redis": redis_ok,
        "latency_ms": _elapsed_ms(start),
    }