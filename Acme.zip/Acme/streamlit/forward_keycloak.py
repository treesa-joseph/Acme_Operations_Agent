import socket
import threading
import time

TARGET_HOST = "keycloak"
TARGET_PORT = 8080
LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 8080


def pipe(src: socket.socket, dst: socket.socket) -> None:
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    finally:
        # Half-close: tell the other side we're done sending, but let
        # the reverse direction finish its response first
        try:
            dst.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def connect_upstream() -> socket.socket | None:
    for _ in range(10):
        try:
            s = socket.create_connection((TARGET_HOST, TARGET_PORT), timeout=5.0)
            s.settimeout(None)  # the fix: the timeout was only meant for connecting
            return s
        except OSError:
            time.sleep(0.5)
    return None


def handle_client(client: socket.socket) -> None:
    upstream = connect_upstream()
    if upstream is None:
        client.close()
        return
    t1 = threading.Thread(target=pipe, args=(client, upstream), daemon=True)
    t2 = threading.Thread(target=pipe, args=(upstream, client), daemon=True)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    client.close()
    upstream.close()


def main() -> None:
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((LISTEN_HOST, LISTEN_PORT))
    srv.listen(128)
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()