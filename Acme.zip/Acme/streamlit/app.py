import os
import json
import base64
import time
import requests
import uuid
import streamlit as st

st.set_page_config(page_title="Acme Operations Assistant", layout="wide")

BACKEND_URL = os.getenv("BACKEND_URL", "http://app:8000").rstrip("/")
APP_ROLES = ("admin", "support_user", "sales_user")
TEST_USERS = {
    "alice_sales": "sales_user",
    "bob_support": "support_user",
    "admin": "admin",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def reset_chat():
    st.session_state.messages = []
    st.session_state.session_id = str(uuid.uuid4())


def is_user_logged_in() -> bool:
    user = getattr(st, "user", None)
    if user is None:
        return False
    try:
        return bool(getattr(user, "is_logged_in", False))
    except (AttributeError, KeyError):
        return False


def get_user_claim(key: str, default=None):
    user = getattr(st, "user", None)
    if user is None:
        return default
    try:
        if hasattr(user, "get"):
            val = user.get(key)
            if val is not None:
                return val
        return getattr(user, key, default)
    except (AttributeError, KeyError):
        return default


def get_token(kind: str) -> str | None:
    """Return st.user.tokens[kind] ('access' or 'id') if exposed."""
    user = getattr(st, "user", None)
    tokens = getattr(user, "tokens", None) if user is not None else None
    if tokens is None:
        return None
    try:
        val = tokens.get(kind) if hasattr(tokens, "get") else getattr(tokens, kind, None)
    except (AttributeError, KeyError, TypeError):
        return None
    return val.strip() if isinstance(val, str) and val.strip() else None


def get_bearer_token() -> str | None:
    return get_token("access") or get_token("id")


def decode_jwt_payload(token: str | None) -> dict:
    """Decode a JWT payload WITHOUT verifying it. Used only to display roles.
    The backend must still verify the signature before trusting anything."""
    if not token:
        return {}
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:
        return {}


def token_seconds_left(token: str | None) -> int | None:
    """Seconds until the JWT expires (negative if already expired); None if it has no `exp`."""
    exp = decode_jwt_payload(token).get("exp")
    return int(exp - time.time()) if exp else None


def extract_user_roles() -> list[str]:
    """Realm/client roles usually live in the ACCESS token, not the ID token,
    so read both the access token and st.user claims."""
    sources = [decode_jwt_payload(get_token("access")), decode_jwt_payload(get_token("id"))]
    roles: list[str] = []

    for claims in sources:
        realm_roles = (claims.get("realm_access") or {}).get("roles") or []
        roles.extend(str(r) for r in realm_roles)
        for client in (claims.get("resource_access") or {}).values():
            roles.extend(str(r) for r in (client or {}).get("roles") or [])

    ra = get_user_claim("realm_access")
    if isinstance(ra, dict) and isinstance(ra.get("roles"), list):
        roles.extend(str(r) for r in ra["roles"])

    roles = list(dict.fromkeys(roles))
    app_roles = [r for r in roles if r in APP_ROLES]
    return app_roles or roles


def do_login():
    """Start Keycloak login. `prompt = "login"` in secrets.toml forces Keycloak
    to show the credentials form, so a different user can sign in each time."""
    reset_chat()
    st.login("keycloak")


def do_logout():
    reset_chat()
    st.logout()

def run_agent_query(prompt: str, username: str, roles: list[str], token: str, history: list[dict]):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    # The backend takes identity and role from the verified token and conversation
    # memory from Redis (by session_id), so nothing else needs to be sent.
    payload = {"query": prompt, "session_id": st.session_state.session_id}
    resp = requests.post(f"{BACKEND_URL}/api/agent/run", json=payload, headers=headers, timeout=120)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response") or data.get("answer") or data


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())

logged_in = is_user_logged_in()
username = roles = token = None
secs_left = None

if logged_in:
    username = get_user_claim("preferred_username") or get_user_claim("name") or "User"
    roles = extract_user_roles() or ["sales_user"]
    token = get_bearer_token()
    secs_left = token_seconds_left(token)

    # A different user signed in on the same browser session: start a clean chat
    if st.session_state.get("current_user") != username:
        st.session_state.current_user = username
        reset_chat()
else:
    st.session_state.pop("current_user", None)

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("Authentication & Role")

    if logged_in:
        st.success(f"Signed in as **{username}**")
        email = get_user_claim("email", "")
        if email:
            st.caption(email)
        st.write("**Active roles:**", ", ".join(roles))
        if secs_left is not None:
            st.caption("Session expired" if secs_left <= 0 else f"Session expires in {max(secs_left // 60, 1)} min")

        if st.button("Switch user", type="primary", use_container_width=True):
            do_logout()  # next login shows the Keycloak form again
        if st.button("New conversation", use_container_width=True):
            reset_chat()
            st.rerun()
        if st.button("Log out", use_container_width=True):
            do_logout()

        with st.expander("Debug"):
            st.write(f"Bearer token present: {bool(token)}")
            st.write(f"Token length: {len(token) if token else 0}")
            tc = decode_jwt_payload(get_token("access"))
            if tc:
                left = int(tc.get("exp", 0) - time.time())
                st.write(f"Token issuer: `{tc.get('iss')}`")
                st.write("Token expires in: " + (f"{left}s" if left > 0 else "**expired**"))
                st.write(f"Realm roles in token: {(tc.get('realm_access') or {}).get('roles', [])}")
            else:
                st.write("Access token is missing or not a JWT.")
    else:
        st.info("Not signed in")
        if st.button("Log in with Keycloak", type="primary", use_container_width=True):
            do_login()

    st.divider()
    st.markdown(
        """
**Role permissions:**
- **sales_user:** Read-only customer/issues
- **support_user:** Read & update issues
- **admin:** Full permissions
"""
    )

# ---------------------------------------------------------------------------
# Main page
# ---------------------------------------------------------------------------
st.title("Acme Operations Assistant")
st.caption("Seamless, secure, and auditable enterprise assistant for support and account management.")

if not logged_in:
    st.subheader("Sign In")
    st.write("Authenticate with your Keycloak account to use the assistant with your assigned role.")

    col1, col2 = st.columns([1, 1])
    with col1:
        if st.button("Continue to Keycloak Login", type="primary", use_container_width=True):
            do_login()
    with col2:
        st.info(
            "**Test accounts**\n\n"
            + "\n".join(f"- `{u}` ({r})" for u, r in TEST_USERS.items())
            + "\n\nKeycloak asks for credentials on every login. "
            "Use **Switch user** in the sidebar to sign in as someone else."
        )
    st.stop()

if not token:
    st.error(
        "Signed in, but no access token is available to the app. "
        "Add `expose_tokens = [\"access\", \"id\"]` to the `[auth]` section of secrets.toml "
        "and restart Streamlit."
    )
    st.stop()

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if secs_left is not None and secs_left <= 10:
    st.warning("Your Keycloak session has expired. Log in again to continue.")
    if st.button("Log in again", type="primary"):
        do_login()
    st.stop()

prompt = st.chat_input("Ask a question or follow up (e.g., 'Show open issues for customer name')")

if prompt and prompt.strip():
    clean_prompt = prompt.strip()
    st.session_state.messages.append({"role": "user", "content": clean_prompt})
    with st.chat_message("user"):
        st.markdown(clean_prompt)

    with st.chat_message("assistant"):
        try:
            with st.spinner("Running agent..."):
                answer = run_agent_query(
                    prompt=clean_prompt,
                    username=username,
                    roles=roles,
                    token=token,
                    history=st.session_state.messages[:-1],
                )
            text = answer if isinstance(answer, str) else str(answer)
            st.markdown(text)
            st.session_state.messages.append({"role": "assistant", "content": text})
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            try:
                detail = exc.response.json().get("detail", "")
            except Exception:
                detail = exc.response.text if exc.response is not None else ""
            if status == 401:
                err = (f"Authentication failed: {detail}. "
                       "Use **Log out**, then log in again to get a fresh token.")
            elif status == 403:
                err = (f"Access denied: {detail}. This Keycloak user needs one of the realm roles "
                       "sales_user, support_user or admin.")
            else:
                err = f"Backend returned an error ({status}): {detail}"
            st.error(err)
            st.session_state.messages.append({"role": "assistant", "content": err})
        except requests.RequestException as exc:
            err = f"Failed to reach backend service: {exc}"
            st.error(err)
            st.session_state.messages.append({"role": "assistant", "content": err})